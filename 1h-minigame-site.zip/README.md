# 1H MINI GAME

이름 + 연락처를 입력하면 60분 세션이 시작되는 미니게임 사이트입니다.

## 포함 게임
- 한글 타자 연습
- 영어 타자 연습
- 탄막 피하기
- 픽셀 러너 (Chrome 공룡게임 스타일)
- 통합 리더보드

## 실행
Node.js 18+ 권장.

```bash
npm install
npm start
```

브라우저에서 `http://localhost:3000` 접속.

점수는 SQLite(`leaderboard.db`)에 저장됩니다.
