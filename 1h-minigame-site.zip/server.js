const express = require("express");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("leaderboard.db");

db.exec(`
CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact_hash TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  player_id INTEGER NOT NULL,
  game TEXT NOT NULL,
  score INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(player_id) REFERENCES players(id)
);
`);

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const crypto = require("crypto");
const hash = v => crypto.createHash("sha256").update(String(v).trim()).digest("hex");

app.post("/api/session", (req, res) => {
  const { name, contact } = req.body || {};
  if (!name || !contact || String(name).trim().length < 1 || String(contact).trim().length < 3) {
    return res.status(400).json({ error: "이름과 연락처를 입력해주세요." });
  }
  const now = new Date().toISOString();
  const ch = hash(contact);
  let player = db.prepare("SELECT * FROM players WHERE contact_hash=?").get(ch);
  if (!player) {
    const result = db.prepare(
      "INSERT INTO players(name, contact_hash, created_at) VALUES(?,?,?)"
    ).run(String(name).trim().slice(0, 30), ch, now);
    player = db.prepare("SELECT * FROM players WHERE id=?").get(result.lastInsertRowid);
  } else if (player.name !== String(name).trim().slice(0, 30)) {
    db.prepare("UPDATE players SET name=? WHERE id=?").run(String(name).trim().slice(0,30), player.id);
    player.name = String(name).trim().slice(0,30);
  }

  res.json({
    playerId: player.id,
    name: player.name,
    expiresAt: Date.now() + 60 * 60 * 1000
  });
});

app.post("/api/score", (req, res) => {
  const { playerId, game, score, sessionStartedAt } = req.body || {};
  const allowed = ["typing-ko", "typing-en", "bullet", "runner"];
  if (!allowed.includes(game) || !Number.isInteger(Number(score)) || !playerId) {
    return res.status(400).json({ error: "잘못된 점수입니다." });
  }

  const started = Number(sessionStartedAt);
  if (!Number.isFinite(started) || Date.now() - started > 60 * 60 * 1000 + 30000) {
    return res.status(403).json({ error: "1시간 플레이 시간이 끝났습니다." });
  }

  const player = db.prepare("SELECT id FROM players WHERE id=?").get(playerId);
  if (!player) return res.status(404).json({ error: "플레이어를 찾을 수 없습니다." });

  db.prepare(
    "INSERT INTO scores(player_id, game, score, created_at) VALUES(?,?,?,?)"
  ).run(playerId, game, Math.max(0, Number(score)), new Date().toISOString());

  res.json({ ok: true });
});

app.get("/api/leaderboard", (req, res) => {
  const rows = db.prepare(`
    SELECT p.name,
      MAX(CASE WHEN s.game='typing-ko' THEN s.score ELSE 0 END) ko,
      MAX(CASE WHEN s.game='typing-en' THEN s.score ELSE 0 END) en,
      MAX(CASE WHEN s.game='bullet' THEN s.score ELSE 0 END) bullet,
      MAX(CASE WHEN s.game='runner' THEN s.score ELSE 0 END) runner
    FROM players p
    LEFT JOIN scores s ON s.player_id=p.id
    GROUP BY p.id
  `).all();

  rows.forEach(r => {
    r.total = r.ko + r.en + r.bullet + r.runner;
  });
  rows.sort((a,b) => b.total - a.total);
  res.json(rows.slice(0, 100));
});

app.listen(PORT, () => console.log(`MiniGame server: http://localhost:${PORT}`));
