const $ = s => document.querySelector(s);
let state = {playerId:null,name:"",startedAt:0,expiresAt:0,currentGame:null,score:0,timer:null,cleanup:null};

const korean = [
"오늘도 즐거운 게임을 시작해 봅시다.",
"빠르고 정확하게 문장을 입력해 보세요.",
"작은 실수가 점수에 영향을 줄 수 있습니다.",
"집중력을 유지하면서 끝까지 도전하세요.",
"새로운 기록에 도전하는 것은 재미있는 일입니다."
];
const english = [
"Speed and accuracy are the keys to a great score.",
"Keep your focus and type every word correctly.",
"Small mistakes can make a big difference.",
"Challenge yourself and beat your previous record.",
"Stay calm, move fast, and enjoy the game."
];

$("#startBtn").onclick = async () => {
  const name = $("#name").value.trim(), contact = $("#contact").value.trim();
  if(!name || !contact){ alert("이름과 연락처를 입력해주세요."); return; }
  const r = await fetch("/api/session",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,contact})});
  const d = await r.json();
  if(!r.ok){alert(d.error||"등록 실패");return}
  state={...state,...d,startedAt:Date.now(),currentGame:"typing-ko",score:0};
  $("#login").classList.add("hidden"); $("#gameArea").classList.remove("hidden");
  $("#playerName").textContent=state.name;
  startTimer(); startGame("typing-ko");
};

function startTimer(){
  clearInterval(state.timer);
  state.timer=setInterval(()=>{
    const left=Math.max(0,state.expiresAt-Date.now());
    const m=String(Math.floor(left/60000)).padStart(2,"0"), s=String(Math.floor(left/1000)%60).padStart(2,"0");
    $("#timer").textContent=`${m}:${s}`;
    $("#timer").classList.toggle("warn",left<5*60000);
    if(left<=0){clearInterval(state.timer); endSession();}
  },250);
}
function endSession(){ if(state.cleanup) state.cleanup(); state.cleanup=null; alert("1시간이 끝났습니다! 리더보드에서 기록을 확인하세요."); showRank(); }

document.querySelectorAll(".tabs button[data-game]").forEach(b=>b.onclick=()=>startGame(b.dataset.game));
$("#rankBtn").onclick=showRank; $("#backBtn").onclick=()=>{ $("#rank").classList.add("hidden"); $("#gameArea").classList.remove("hidden"); };

function setGame(html){ $("#game").innerHTML=html; state.score=0; $("#score").textContent=0; }
async function submitScore(game,score){
  if(Date.now()>state.expiresAt)return;
  await fetch("/api/score",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
    playerId:state.playerId,game,score,sessionStartedAt:state.startedAt
  })});
}
function addScore(n){state.score+=n;$("#score").textContent=state.score}

function startGame(game){
  if(Date.now()>state.expiresAt)return;
  if(state.cleanup)state.cleanup();
  state.currentGame=game;
  if(game==="typing-ko"||game==="typing-en") typing(game);
  if(game==="bullet") bullet();
  if(game==="runner") runner();
}

function typing(game){
  const arr=game==="typing-ko"?korean:english;
  let idx=0, correct=0, started=Date.now(), locked=false;
  setGame(`<h2>${game==="typing-ko"?"한글 타자 연습":"영어 타자 연습"}</h2>
  <p class="hint">문장을 정확히 입력하고 Enter를 누르세요. 빠를수록 높은 점수!</p>
  <div class="typing-box"><span class="target">${arr[idx]}</span></div>
  <input class="typing-input" autofocus placeholder="여기에 입력하세요">`);
  const input=$(".typing-input");
  input.focus();
  const next=()=>{
    if(locked)return;
    if(input.value.trim()===arr[idx]){
      const sec=(Date.now()-started)/1000;
      const pts=Math.max(10,Math.round(120-sec*8));
      addScore(pts); correct++; idx=(idx+1)%arr.length; started=Date.now();
      $(".target").textContent=arr[idx]; input.value="";
      if(correct%5===0)submitScore(game,state.score);
    }else input.animate([{transform:"translateX(-4px)"},{transform:"translateX(4px)"},{transform:"translateX(0)"}],{duration:150});
  };
  input.addEventListener("keydown",e=>{if(e.key==="Enter")next()});
  state.cleanup=()=>{locked=true;input.removeEventListener("keydown",next)};
}

function bullet(){
  setGame(`<h2>탄막 미니게임</h2><p class="hint">마우스/손가락으로 이동해서 탄막을 피하세요. 오래 버틸수록 점수 증가!</p>
  <div class="canvas-wrap"><canvas class="gamecanvas" width="760" height="430"></canvas></div>`);
  const c=$(".gamecanvas"),x=c.getContext("2d"); let px=380,py=360,balls=[],alive=true,last=performance.now(),spawn=0,score=0;
  const move=e=>{const r=c.getBoundingClientRect();const q=e.touches?e.touches[0]:e;px=(q.clientX-r.left)*c.width/r.width;py=(q.clientY-r.top)*c.height/r.height};
  c.addEventListener("pointermove",move); c.addEventListener("touchmove",move,{passive:true});
  function frame(t){if(!alive)return; const dt=Math.min(0.04,(t-last)/1000);last=t;spawn+=dt;
    if(spawn>.18){spawn=0;let a=Math.random()*Math.PI*2,spd=90+Math.random()*110;balls.push({x:380,y:40,r:6,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd+80});}
    balls.forEach(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt});
    balls=balls.filter(b=>b.x>-20&&b.x<c.width+20&&b.y>-20&&b.y<c.height+20);
    x.clearRect(0,0,c.width,c.height);x.fillStyle="#080b10";x.fillRect(0,0,c.width,c.height);
    x.fillStyle="#58a6ff";x.beginPath();x.arc(px,py,9,0,7);x.fill();
    x.fillStyle="#ff7b72";balls.forEach(b=>{x.beginPath();x.arc(b.x,b.y,b.r,0,7);x.fill()});
    for(const b of balls)if(Math.hypot(b.x-px,b.y-py)<b.r+10){alive=false;addScore(Math.floor(score));submitScore("bullet",state.score);alert("피격! 점수: "+state.score);return}
    score+=dt*10;addScore(Math.floor(dt*10));requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame); state.cleanup=()=>{alive=false;c.removeEventListener("pointermove",move)};
}

function runner(){
  setGame(`<h2>픽셀 러너</h2><p class="hint">Space / 화면 터치로 점프하세요. 장애물을 피하며 오래 달리기!</p>
  <div class="canvas-wrap"><canvas class="gamecanvas" width="760" height="300"></canvas></div>`);
  const c=$(".gamecanvas"),x=c.getContext("2d");let y=230,vy=0,ground=true,obs=[],t=0,alive=true,raf;
  const jump=()=>{if(ground){vy=-480;ground=false}}; window.addEventListener("keydown",e=>{if(e.code==="Space")jump()});c.addEventListener("pointerdown",jump);
  function frame(dt){if(!alive)return;t+=dt;vy+=1200*dt;y+=vy*dt;if(y>=230){y=230;vy=0;ground=true}
    if(Math.random()<dt*.9)obs.push({x:760,w:22+Math.random()*22,h:30+Math.random()*40});
    obs.forEach(o=>o.x-=320*dt);obs=obs.filter(o=>o.x>-50);
    x.clearRect(0,0,760,300);x.fillStyle="#080b10";x.fillRect(0,0,760,300);
    x.fillStyle="#30363d";x.fillRect(0,250,760,2);x.fillStyle="#58a6ff";x.fillRect(80,y-20,25,20);
    x.fillStyle="#ff7b72";obs.forEach(o=>x.fillRect(o.x,250-o.h,o.w,o.h));
    for(const o of obs)if(80+25>o.x&&80<o.x+o.w&&y>250-o.h){alive=false;submitScore("runner",state.score);alert("게임 오버! 점수: "+state.score);return}
    addScore(Math.max(1,Math.floor(dt*12)));raf=requestAnimationFrame(()=>frame(Math.min(.04,(performance.now()-last)/1000)));last=performance.now()
  }
  let last=performance.now();raf=requestAnimationFrame(()=>frame(0));state.cleanup=()=>{alive=false;cancelAnimationFrame(raf);window.removeEventListener("keydown",jump)}
}

async function showRank(){
  if(state.cleanup)state.cleanup();state.cleanup=null;
  $("#gameArea").classList.add("hidden");$("#rank").classList.remove("hidden");
  const r=await fetch("/api/leaderboard");const rows=await r.json();
  $("#rankTable").innerHTML=`<table class="ranktable"><thead><tr><th>#</th><th>이름</th><th>한글</th><th>영어</th><th>탄막</th><th>러너</th><th>총점</th></tr></thead><tbody>
  ${rows.map((r,i)=>`<tr><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${r.ko}</td><td>${r.en}</td><td>${r.bullet}</td><td>${r.runner}</td><td><b>${r.total}</b></td></tr>`).join("")}</tbody></table>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
